//
// Created by bruni on 24/02/2024.
//
#include "Employee.h"

int main() {
    EmployeeRecords e;
    e.Fill();
    e.Show();
    e.Order();
    e.Show();
    return 0;
}